import base64
import requests
from django.shortcuts import render
from django.conf import settings

API_KEY = '0lch9VsrIN2jmHVyrDCW3HZ7iYKuysTiBfySJkSqlVYbXtneDq'

manual_treatments = {
    "Fungi": {
        "chemical": ["Apply fungicides like copper or sulfur sprays"],
        "prevention": ["Avoid water on leaves", "Improve airflow", "Remove infected foliage"]
    },
    "bacterial leaf spot": {
        "chemical": ["Use copper-based bactericides"],
        "prevention": ["Avoid splashing water", "Remove infected leaves"]
    }
}

def plant_health_assessment(request):
    context = {}
    if request.method == 'POST':
        uploaded_file = request.FILES.get('image')
        if uploaded_file:
            image_data = base64.b64encode(uploaded_file.read()).decode("utf-8")

            url = "https://api.plant.id/v3/health_assessment?details=local_name,description,url,treatment,classification,common_names,cause"
            headers = {
                "Content-Type": "application/json",
                "Api-Key": API_KEY
            }
            payload = {
                "images": [image_data],
                "health": "only"
            }

            try:
                response = requests.post(url, headers=headers, json=payload)
                data = response.json()

                is_plant = data["result"]["is_plant"]["binary"]
                plant_prob = data["result"]["is_plant"]["probability"]

                is_healthy = data["result"]["is_healthy"]["binary"]
                health_prob = data["result"]["is_healthy"]["probability"]

                suggestions = data["result"]["disease"].get("suggestions", [])

                # Enhance disease data with manual fallback
                for s in suggestions:
                    name = s["name"]
                    s["probability_percent"] = f"{s['probability'] * 100:.2f}"
                    s["treatment"] = s.get("details", {}).get("treatment", manual_treatments.get(name, {}))
                    s["cause"] = s.get("details", {}).get("cause")

                context.update({
                    "is_plant": is_plant,
                    "plant_prob": f"{plant_prob * 100:.2f}",
                    "is_healthy": is_healthy,
                    "health_prob": f"{health_prob * 100:.2f}",
                    "diseases": suggestions,
                })

            except Exception as e:
                context["error"] = f"Error: {str(e)}"

    return render(request, 'plant_result.html', context)
