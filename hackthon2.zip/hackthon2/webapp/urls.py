from django.urls import path
from . import views

urlpatterns = [
    path("", views.plant_health_assessment, name="plant_check"),
]
